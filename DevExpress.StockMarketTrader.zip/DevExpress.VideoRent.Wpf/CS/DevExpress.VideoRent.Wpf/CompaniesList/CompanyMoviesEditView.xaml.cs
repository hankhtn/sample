﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class CompanyMoviesEditView : UserControl {
        public CompanyMoviesEditView() {
            InitializeComponent();
        }
    }
}
