namespace DevExpress.DevAV{
    public class MapUtils{
        const string key = DevExpress.Map.Native.DXBingKeyVerifier.BingKeyWpfHybridApp;
        public string DevExpressBingKey { get { return key; } }
    }
}
