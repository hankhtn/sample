using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class ProductCollectionView : UserControl {
        public ProductCollectionView() {
            InitializeComponent();
        }
    }
}
