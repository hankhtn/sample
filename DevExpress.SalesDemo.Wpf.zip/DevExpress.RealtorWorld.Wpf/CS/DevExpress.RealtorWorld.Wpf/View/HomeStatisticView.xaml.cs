using System;
using System.Linq;
using System.Windows.Controls;
using System.Collections.Generic;

namespace DevExpress.RealtorWorld.Xpf.View{
    public partial class HomeStatisticView : UserControl {
        public HomeStatisticView() {
            InitializeComponent();
        }
    }
}
