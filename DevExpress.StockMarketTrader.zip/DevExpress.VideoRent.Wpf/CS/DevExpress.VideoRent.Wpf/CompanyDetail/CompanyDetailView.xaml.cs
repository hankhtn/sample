﻿using DevExpress.VideoRent.Wpf.ModulesBase;
using DevExpress.VideoRent.ViewModel.ViewModelBase;
using DevExpress.VideoRent.Resources;

namespace DevExpress.VideoRent.Wpf {
    public partial class CompanyDetailView : DemoModule {
        public CompanyDetailView() {
            InitializeComponent();
        }
    }
}
