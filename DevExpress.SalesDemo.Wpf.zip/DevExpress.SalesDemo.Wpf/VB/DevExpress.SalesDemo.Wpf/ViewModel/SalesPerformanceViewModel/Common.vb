Namespace DevExpress.SalesDemo.Wpf.ViewModel
    Public Enum PerformanceViewMode
        Daily
        Monthly
    End Enum
End Namespace
