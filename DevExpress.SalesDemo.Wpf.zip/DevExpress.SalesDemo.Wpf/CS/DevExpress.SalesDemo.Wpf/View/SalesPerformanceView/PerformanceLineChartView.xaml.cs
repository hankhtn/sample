using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class PerformanceLineChartView : UserControl {
        public PerformanceLineChartView() {
            InitializeComponent();
        }
    }
}
