Imports System
Imports System.Linq
Imports System.Windows.Controls
Imports System.Collections.Generic
Imports DevExpress.Xpf.WindowsUI
Imports DevExpress.Mvvm.UI
Imports System.Windows.Input

Namespace DevExpress.DevAV.Views
    Partial Public Class EmployeeCollectionView
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
