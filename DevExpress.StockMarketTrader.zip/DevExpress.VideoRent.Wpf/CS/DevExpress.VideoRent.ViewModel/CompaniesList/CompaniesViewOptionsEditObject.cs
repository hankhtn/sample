﻿using System;
using DevExpress.VideoRent.ViewModel.ViewModelBase;

namespace DevExpress.VideoRent.ViewModel {
    public class CompaniesViewOptionsEditObject : EditableSubobject {
        public CompaniesViewOptionsEditObject(EditableObject parent) : base(parent) { }
        protected override void UpdateOverride() { }
    }
}
