Imports System.Windows.Controls

Namespace DevExpress.DevAV.Views
    Partial Public Class TaskCollectionView
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
