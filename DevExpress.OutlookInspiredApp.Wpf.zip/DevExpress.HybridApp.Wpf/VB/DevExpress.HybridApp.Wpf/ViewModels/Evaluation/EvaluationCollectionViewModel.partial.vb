Imports System
Imports System.Linq
Imports DevExpress.DevAV.Common.Utils
Imports DevExpress.DevAV.DevAVDbDataModel
Imports DevExpress.DevAV
Imports DevExpress.DevAV.Common.ViewModel
Imports DevExpress.DevAV.ViewModels

Namespace DevExpress.DevAV.ViewModels
    Partial Public Class EvaluationCollectionViewModel
    End Class
End Namespace
