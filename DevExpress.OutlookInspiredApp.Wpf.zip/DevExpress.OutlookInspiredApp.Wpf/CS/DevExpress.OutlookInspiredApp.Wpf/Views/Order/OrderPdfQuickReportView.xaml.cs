using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class OrderPdfQuickReportView : UserControl {
        public OrderPdfQuickReportView() {
            InitializeComponent();
        }
    }
}
