using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class EmployeeTaskDetailView : UserControl {
        public EmployeeTaskDetailView() {
            InitializeComponent();
        }
    }
}
