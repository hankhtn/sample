using DevExpress.Mvvm.UI.Interactivity;
using DevExpress.Xpf.Grid;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace DevExpress.DevAV.Views {
    public partial class EmployeeCollectionView : UserControl {
        public EmployeeCollectionView() {
            InitializeComponent();
        }
    }
}
