using System;
using System.Linq;
using System.Windows.Controls;
using System.Collections.Generic;
using DevExpress.Xpf.WindowsUI;
using DevExpress.Mvvm.UI;
using System.Windows.Input;

namespace DevExpress.DevAV.Views {
    public partial class EmployeeCollectionView : UserControl {
        public EmployeeCollectionView() {
            InitializeComponent();
        }
    }
}
