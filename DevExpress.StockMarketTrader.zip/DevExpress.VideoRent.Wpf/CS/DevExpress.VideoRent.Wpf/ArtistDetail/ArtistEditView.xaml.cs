﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class ArtistEditView : UserControl {
        public ArtistEditView() {
            InitializeComponent();
        }
    }
}
