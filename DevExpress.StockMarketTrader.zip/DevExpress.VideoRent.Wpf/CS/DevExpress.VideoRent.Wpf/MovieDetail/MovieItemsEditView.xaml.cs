﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieItemsEditView : CustomShowUserControl {
        public MovieItemsEditView() {
            InitializeComponent();
        }
    }
}
