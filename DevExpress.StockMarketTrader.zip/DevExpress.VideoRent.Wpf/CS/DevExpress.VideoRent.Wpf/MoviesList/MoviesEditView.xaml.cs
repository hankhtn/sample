﻿using System.Windows.Controls;
using DevExpress.Xpf.Grid;
using System.Collections;

namespace DevExpress.VideoRent.Wpf {
    public partial class MoviesEditView : UserControl {
        public MoviesEditView() {
            InitializeComponent();
        }
    }
}
