using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class OrderMailMergeView : UserControl {
        public OrderMailMergeView() {
            InitializeComponent();
        }
    }
}
