﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class RentsPeriodEditView : CustomShowUserControl {
        public RentsPeriodEditView() {
            InitializeComponent();
        }
    }
}
