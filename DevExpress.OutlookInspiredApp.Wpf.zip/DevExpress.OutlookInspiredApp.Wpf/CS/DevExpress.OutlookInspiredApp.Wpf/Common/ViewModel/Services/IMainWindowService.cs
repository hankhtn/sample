using System;

namespace DevExpress.DevAV.Common.ViewModel {
    public interface IMainWindowService {
        string Title { get; set; }
    }
}
