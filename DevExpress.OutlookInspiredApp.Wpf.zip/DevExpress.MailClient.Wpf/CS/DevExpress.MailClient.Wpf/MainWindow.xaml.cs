using DevExpress.Xpf.Core;

namespace DevExpress.MailClient.View {
    public partial class MainWindow : ThemedWindow {
        public MainWindow() {
            InitializeComponent();
        }
    }
}
