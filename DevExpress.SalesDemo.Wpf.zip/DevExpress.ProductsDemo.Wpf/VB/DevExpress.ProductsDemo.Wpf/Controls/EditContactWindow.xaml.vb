Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Shapes
Imports DevExpress.Xpf.Ribbon
Imports DevExpress.Xpf.Core

Namespace ProductsDemo.Controls



    Partial Public Class EditContactWindow
        Inherits ThemedWindow

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
