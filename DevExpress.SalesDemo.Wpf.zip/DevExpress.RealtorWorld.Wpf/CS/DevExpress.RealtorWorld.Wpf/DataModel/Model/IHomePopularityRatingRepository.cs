using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IHomePopularityRatingRepository : IRepository<HomePopularityRating, int> { }
}
