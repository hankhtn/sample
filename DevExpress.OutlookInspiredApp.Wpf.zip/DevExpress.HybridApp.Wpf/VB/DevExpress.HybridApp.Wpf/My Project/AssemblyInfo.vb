Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows

<Assembly: AssemblyTitle("DevExpress Hybrid Application")>
<Assembly: AssemblyDescription("DevExpress Hybrid Application")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany(AssemblyInfo.AssemblyCompany)>
<Assembly: AssemblyProduct("DevExpress WPF")>
<Assembly: AssemblyCopyright(AssemblyInfo.AssemblyCopyright)>
<Assembly: AssemblyTrademark("DevExpress WPF")>
<Assembly: AssemblyCulture("")>

<Assembly: ComVisible(False)>
<Assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)>

<Assembly: AssemblyVersion(AssemblyInfo.Version)>
<Assembly: AssemblyFileVersion(AssemblyInfo.FileVersion)>
