﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class CustomersListView : DemoModule {
        public CustomersListView() {
            InitializeComponent();
        }
    }
}
