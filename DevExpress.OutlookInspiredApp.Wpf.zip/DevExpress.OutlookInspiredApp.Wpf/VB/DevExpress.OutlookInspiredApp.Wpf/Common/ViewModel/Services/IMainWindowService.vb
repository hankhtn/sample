Imports System

Namespace DevExpress.DevAV.Common.ViewModel
    Public Interface IMainWindowService
        Property Title() As String
    End Interface
End Namespace
