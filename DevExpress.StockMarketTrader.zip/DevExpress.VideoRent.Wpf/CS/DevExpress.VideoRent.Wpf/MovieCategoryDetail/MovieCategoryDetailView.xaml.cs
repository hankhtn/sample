﻿using System.Windows;
using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieCategoryDetailView : CustomShowUserControl {
        public MovieCategoryDetailView() {
            InitializeComponent();
        }
    }
}
