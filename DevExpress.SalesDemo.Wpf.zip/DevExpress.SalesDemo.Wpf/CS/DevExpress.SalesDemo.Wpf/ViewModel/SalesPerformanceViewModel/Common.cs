namespace DevExpress.SalesDemo.Wpf.ViewModel {
    public enum PerformanceViewMode { Daily, Monthly }
}
