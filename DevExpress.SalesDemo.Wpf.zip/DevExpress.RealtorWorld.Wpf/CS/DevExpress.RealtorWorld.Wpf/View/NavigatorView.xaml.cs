using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DevExpress.RealtorWorld.Xpf.View {
    public partial class NavigatorView : UserControl {
        public NavigatorView() {
            InitializeComponent();
        }
    }
}
