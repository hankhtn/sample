Imports System.Windows.Controls

Namespace DevExpress.SalesDemo.Wpf.View
    Partial Public Class RegionsView
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
