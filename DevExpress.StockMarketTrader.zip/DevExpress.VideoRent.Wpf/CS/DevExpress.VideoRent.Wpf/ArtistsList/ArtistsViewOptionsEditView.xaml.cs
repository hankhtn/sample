﻿using System;
using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class ArtistsViewOptionsEditView : CustomShowUserControl {
        public ArtistsViewOptionsEditView() {
            InitializeComponent();
        }
    }
}
