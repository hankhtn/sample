using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class LoginView : UserControl {
        public LoginView() {
            InitializeComponent();
        }
    }
}
