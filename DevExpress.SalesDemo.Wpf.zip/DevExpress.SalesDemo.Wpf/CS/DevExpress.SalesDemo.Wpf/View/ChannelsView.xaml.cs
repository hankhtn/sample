using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class ChannelsView : UserControl {
        public ChannelsView() {
            InitializeComponent();
        }
    }
}
