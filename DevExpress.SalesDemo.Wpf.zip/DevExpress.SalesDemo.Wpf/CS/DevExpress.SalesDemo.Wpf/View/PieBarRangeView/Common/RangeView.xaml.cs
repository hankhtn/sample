using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class RangeView : UserControl {
        public RangeView() {
            InitializeComponent();
        }
    }
}
