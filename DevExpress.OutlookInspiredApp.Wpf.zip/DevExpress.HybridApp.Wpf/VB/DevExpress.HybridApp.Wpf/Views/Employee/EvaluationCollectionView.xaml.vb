Imports System
Imports System.Linq
Imports System.Windows.Controls
Imports System.Collections.Generic

Namespace DevExpress.DevAV.Views
    Partial Public Class EvaluationCollectionView
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
