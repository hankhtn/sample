using System;
using System.Windows;
using System.Windows.Controls;
using DevExpress.Mvvm.UI.Interactivity;

namespace DevExpress.DevAV.Views {
    public partial class EmployeeView : UserControl {
        public EmployeeView() {
            InitializeComponent();
        }
    }
}
