using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class CustomFlagView : UserControl {
        public CustomFlagView() {
            InitializeComponent();
        }
    }
}
