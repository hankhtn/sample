using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IHomeLayoutRepository : IRepository<HomeLayout, int> { }
}
