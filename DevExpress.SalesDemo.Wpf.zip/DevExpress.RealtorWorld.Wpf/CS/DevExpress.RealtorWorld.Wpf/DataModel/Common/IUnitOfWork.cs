using System;
using System.Linq;
using System.Collections.Generic;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IUnitOfWork { }
}
