﻿using System;
using DevExpress.VideoRent.ViewModel.ViewModelBase;

namespace DevExpress.VideoRent.ViewModel {
    public class RentsViewOptionsEditObject : EditableSubobject {
        public RentsViewOptionsEditObject(EditableObject parent) : base(parent) { }
        protected override void UpdateOverride() { }
    }
}
