﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class CompaniesEditView : UserControl {
        public CompaniesEditView() {
            InitializeComponent();
        }
    }
}
