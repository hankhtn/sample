Imports System.Windows.Controls

Namespace DevExpress.SalesDemo.Wpf.View
    Partial Public Class ProgressSplashScreenView
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
