using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class TaskCollectionView : UserControl {
        public TaskCollectionView() {
            InitializeComponent();
        }
    }
}
