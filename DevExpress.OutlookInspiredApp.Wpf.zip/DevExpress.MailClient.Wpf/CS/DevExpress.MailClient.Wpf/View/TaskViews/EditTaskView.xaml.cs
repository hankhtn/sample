using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class EditTaskView : UserControl {
        public EditTaskView() {
            InitializeComponent();
        }
    }
}
