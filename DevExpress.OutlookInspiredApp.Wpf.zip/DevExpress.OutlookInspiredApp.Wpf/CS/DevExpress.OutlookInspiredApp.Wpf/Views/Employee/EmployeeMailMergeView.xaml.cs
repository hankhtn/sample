using DevExpress.Xpf.Bars;
using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class EmployeeMailMergeView : UserControl {
        public EmployeeMailMergeView() {
            InitializeComponent();
        }
    }
}
