using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface ISimilarHousesStatisticDataRepository : IRepository<SimilarHousesStatisticData, int> { }
}
