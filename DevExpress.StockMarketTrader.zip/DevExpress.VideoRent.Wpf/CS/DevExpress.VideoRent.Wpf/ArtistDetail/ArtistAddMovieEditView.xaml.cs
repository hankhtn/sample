﻿using System.Windows.Controls;
using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class ArtistAddMovieEditView : CustomShowUserControl{
        public ArtistAddMovieEditView() {
            InitializeComponent();
        }
    }
}
