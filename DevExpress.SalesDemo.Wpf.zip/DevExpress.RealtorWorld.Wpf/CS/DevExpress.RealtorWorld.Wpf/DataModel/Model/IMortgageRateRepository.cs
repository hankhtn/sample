using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IMortgageRateRepository : IRepository<MortgageRate, DateTime> { }
}
