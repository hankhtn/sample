Imports System.Windows.Controls

Namespace ProductsDemo.Modules
    Partial Public Class ReportsModule
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
