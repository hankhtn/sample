﻿using System;
using DevExpress.VideoRent.ViewModel.ViewModelBase;

namespace DevExpress.VideoRent.ViewModel {
    public class CustomersViewOptionsEditObject : EditableSubobject {
        public CustomersViewOptionsEditObject(EditableObject parent) : base(parent) { }
        protected override void UpdateOverride() { }
    }
}
