using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class SalesBySectorView : UserControl {
        public SalesBySectorView() {
            InitializeComponent();
        }
    }
}
