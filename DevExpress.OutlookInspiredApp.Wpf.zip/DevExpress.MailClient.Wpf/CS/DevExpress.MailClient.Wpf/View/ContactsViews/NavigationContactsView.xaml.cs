using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class NavigationContactsView : UserControl {
        public NavigationContactsView() {
            InitializeComponent();
        }
    }
}
