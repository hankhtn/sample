﻿using System;
using DevExpress.VideoRent.ViewModel.ViewModelBase;

namespace DevExpress.VideoRent.ViewModel {
    public class ArtistsViewOptionsEditObject : EditableSubobject {
        public ArtistsViewOptionsEditObject(EditableObject parent) : base(parent) { }
        protected override void UpdateOverride() { }
    }
}
