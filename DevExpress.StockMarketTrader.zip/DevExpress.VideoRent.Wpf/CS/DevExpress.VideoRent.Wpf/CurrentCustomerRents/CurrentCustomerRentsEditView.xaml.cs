﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class CurrentCustomerRentsEditView : UserControl {
        public CurrentCustomerRentsEditView() {
            InitializeComponent();
        }
    }
}
