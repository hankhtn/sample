Imports System
Imports System.Linq
Imports System.Linq.Expressions
Imports System.Collections.Generic
Imports System.Collections.ObjectModel
Imports DevExpress.Mvvm
Imports DevExpress.Mvvm.POCO
Imports DevExpress.DevAV.Common.Utils
Imports DevExpress.DevAV.DevAVDbDataModel
Imports DevExpress.DevAV
Imports DevExpress.DevAV.Common.ViewModel
Imports DevExpress.DevAV.ViewModels

Namespace DevExpress.DevAV.ViewModels
    Partial Public Class QuoteViewModel
    End Class
End Namespace
