using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class NavigationTasksView : UserControl {
        public NavigationTasksView() {
            InitializeComponent();
        }
    }
}
