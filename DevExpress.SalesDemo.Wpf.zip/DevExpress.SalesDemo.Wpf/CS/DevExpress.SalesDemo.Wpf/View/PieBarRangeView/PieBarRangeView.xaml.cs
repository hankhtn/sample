using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class PieBarRangeView : UserControl {
        public PieBarRangeView() {
            InitializeComponent();
        }
    }
}
