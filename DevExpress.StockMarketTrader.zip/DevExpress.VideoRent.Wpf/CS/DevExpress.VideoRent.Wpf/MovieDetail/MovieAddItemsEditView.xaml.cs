﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieAddItemsEditView : CustomShowUserControl {
        public MovieAddItemsEditView() {
            InitializeComponent();
        }
    }
}
