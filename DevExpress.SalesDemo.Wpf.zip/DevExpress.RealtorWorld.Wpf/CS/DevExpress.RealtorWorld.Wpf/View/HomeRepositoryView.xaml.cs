using System;
using System.Linq;
using System.Windows.Controls;
using System.Collections.Generic;

namespace DevExpress.RealtorWorld.Xpf.View{
    public partial class HomeRepositoryView : UserControl {
        public HomeRepositoryView() {
            InitializeComponent();
        }

        private void Grid_MouseLeftButtonUp_1(object sender, System.Windows.Input.MouseButtonEventArgs e) {

        }
    }
}
