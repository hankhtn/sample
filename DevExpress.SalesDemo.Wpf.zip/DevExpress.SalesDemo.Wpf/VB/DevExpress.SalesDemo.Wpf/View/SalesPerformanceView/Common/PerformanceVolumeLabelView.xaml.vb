Imports DevExpress.SalesDemo.Wpf.Controls
Imports System.Windows.Controls

Namespace DevExpress.SalesDemo.Wpf.View.Common
    Partial Public Class PerformanceVolumeLabelView
        Inherits VolumeLabelControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
