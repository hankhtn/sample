﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class AnnouncerView : UserControl {
        public AnnouncerView() {
            InitializeComponent();
        }
    }
}
