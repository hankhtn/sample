using System;
using System.Linq;
using System.Windows.Controls;
using System.Collections.Generic;

namespace DevExpress.DevAV.Views {
    public partial class EmployeePanelView : UserControl {
        public EmployeePanelView() {
            InitializeComponent();
        }
    }
}
