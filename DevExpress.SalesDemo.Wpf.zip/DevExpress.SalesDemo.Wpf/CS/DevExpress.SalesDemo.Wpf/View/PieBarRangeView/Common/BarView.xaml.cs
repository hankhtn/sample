using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class BarView : UserControl {
        public BarView() {
            InitializeComponent();
        }
    }
}
