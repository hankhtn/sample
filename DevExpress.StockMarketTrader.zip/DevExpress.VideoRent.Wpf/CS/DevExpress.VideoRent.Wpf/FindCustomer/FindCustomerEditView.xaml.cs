﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class FindCustomerEditView : UserControl {
        public FindCustomerEditView() {
            InitializeComponent();
        }
    }
}
