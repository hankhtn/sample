using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class ReportDesignerView : UserControl {
        public ReportDesignerView() {
            InitializeComponent();
        }
    }
}
