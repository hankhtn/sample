﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieAddArtistEditView : CustomShowUserControl {
        public MovieAddArtistEditView() {
            InitializeComponent();
        }
    }
}
