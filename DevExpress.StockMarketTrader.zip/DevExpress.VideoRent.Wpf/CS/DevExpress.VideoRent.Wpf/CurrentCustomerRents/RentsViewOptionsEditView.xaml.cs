﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class RentsViewOptionsEditView : CustomShowUserControl {
        public RentsViewOptionsEditView() {
            InitializeComponent();
        }
    }
}
