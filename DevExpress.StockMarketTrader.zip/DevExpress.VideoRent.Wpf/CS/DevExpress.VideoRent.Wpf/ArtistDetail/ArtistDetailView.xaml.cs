﻿using DevExpress.VideoRent.Wpf.ModulesBase;
using DevExpress.VideoRent.ViewModel.ViewModelBase;
using DevExpress.VideoRent.Resources;

namespace DevExpress.VideoRent.Wpf {
    public partial class ArtistDetailView : DemoModule {
        public ArtistDetailView() {
            InitializeComponent();
        }
    }
}
