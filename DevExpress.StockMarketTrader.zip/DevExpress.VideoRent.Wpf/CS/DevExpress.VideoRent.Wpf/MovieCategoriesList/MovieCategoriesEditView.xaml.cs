﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieCategoriesEditView : UserControl {
        public MovieCategoriesEditView() {
            InitializeComponent();
        }
    }
}
