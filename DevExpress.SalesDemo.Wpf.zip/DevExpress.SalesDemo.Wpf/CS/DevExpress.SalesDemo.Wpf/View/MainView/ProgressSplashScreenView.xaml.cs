using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class ProgressSplashScreenView : UserControl {
        public ProgressSplashScreenView() {
            InitializeComponent();
        }
    }
}
