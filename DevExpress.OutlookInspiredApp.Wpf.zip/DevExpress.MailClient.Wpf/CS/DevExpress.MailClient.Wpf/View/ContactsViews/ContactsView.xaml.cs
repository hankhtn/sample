using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class ContactsView : UserControl {
        public ContactsView() {
            InitializeComponent();
        }
    }
}
