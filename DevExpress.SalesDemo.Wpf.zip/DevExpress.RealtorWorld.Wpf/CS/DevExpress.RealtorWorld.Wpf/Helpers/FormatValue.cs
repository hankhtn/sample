using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevExpress.RealtorWorld.Xpf.Helpers {
    public class FormatValue {
        public object Value { get; set; }
        public string Text { get; set; }
    }
}
