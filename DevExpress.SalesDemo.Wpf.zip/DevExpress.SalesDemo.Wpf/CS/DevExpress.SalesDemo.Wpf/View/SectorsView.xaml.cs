using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class SectorsView : UserControl {
        public SectorsView() {
            InitializeComponent();
        }
    }
}
