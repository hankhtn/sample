using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class RegionsView : UserControl {
        public RegionsView() {
            InitializeComponent();
        }
    }
}
