﻿using System.Windows;
using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieCategoriesListView : DemoModule {
        public MovieCategoriesListView() {
            InitializeComponent();
        }
    }
}
