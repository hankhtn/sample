﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieAddCompanyEditView : CustomShowUserControl {
        public MovieAddCompanyEditView() {
            InitializeComponent();
        }
    }
}
