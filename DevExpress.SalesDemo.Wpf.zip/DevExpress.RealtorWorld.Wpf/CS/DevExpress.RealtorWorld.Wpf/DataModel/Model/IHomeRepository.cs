using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IHomeRepository : IRepository<Home, int> { }
}
