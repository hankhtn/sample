using System.Windows.Controls;

namespace ProductsDemo.Modules {
    public partial class ReportsModule : UserControl {
        public ReportsModule() {
            InitializeComponent();
        }
    }
}
