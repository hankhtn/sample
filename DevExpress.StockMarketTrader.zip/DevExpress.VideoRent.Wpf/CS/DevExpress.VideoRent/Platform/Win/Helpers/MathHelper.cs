using System;

namespace DevExpress.VideoRent.Helpers {
    public static class MathHelper {
        public static decimal Ceiling(decimal d) {
            return Math.Ceiling(d);
        }
    }
}
