﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class CompanyEditView : UserControl {
        public CompanyEditView() {
            InitializeComponent();
        }
    }
}
