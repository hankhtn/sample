using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IHomePriceStatisticDataRepository : IRepository<HomePriceStatisticData, HomePriceStatisticDataKey> { }
}
