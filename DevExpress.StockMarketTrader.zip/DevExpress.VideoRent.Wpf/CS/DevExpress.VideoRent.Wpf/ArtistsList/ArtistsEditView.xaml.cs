﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class ArtistsEditView : UserControl {
        public ArtistsEditView() {
            InitializeComponent();
        }
    }
}
