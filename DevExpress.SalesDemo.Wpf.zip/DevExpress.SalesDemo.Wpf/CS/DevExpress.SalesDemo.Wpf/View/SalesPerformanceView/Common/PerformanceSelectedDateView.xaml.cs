using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class PerformanceSelectedDateView : UserControl {
        public PerformanceSelectedDateView() {
            InitializeComponent();
        }
    }
}
