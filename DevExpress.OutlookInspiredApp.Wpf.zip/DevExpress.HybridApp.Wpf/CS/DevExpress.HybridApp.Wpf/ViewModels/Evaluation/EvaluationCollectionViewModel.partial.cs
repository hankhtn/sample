using System;
using System.Linq;
using DevExpress.DevAV.Common.Utils;
using DevExpress.DevAV.DevAVDbDataModel;
using DevExpress.DevAV;
using DevExpress.DevAV.Common.ViewModel;
using DevExpress.DevAV.ViewModels;

namespace DevExpress.DevAV.ViewModels {
    partial class EvaluationCollectionViewModel {
    }
}
