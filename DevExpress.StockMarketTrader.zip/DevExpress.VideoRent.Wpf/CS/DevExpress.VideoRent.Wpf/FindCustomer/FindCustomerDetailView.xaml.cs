﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class FindCustomerDetailView : CustomShowUserControl {
        public FindCustomerDetailView() {
            InitializeComponent();
        }
    }
}
