using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class NavigationItemView : UserControl {
        public NavigationItemView() {
            InitializeComponent();
        }
    }
}
