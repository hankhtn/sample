﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieCategoryEditView : UserControl {
        public MovieCategoryEditView() {
            InitializeComponent();
        }
    }
}
