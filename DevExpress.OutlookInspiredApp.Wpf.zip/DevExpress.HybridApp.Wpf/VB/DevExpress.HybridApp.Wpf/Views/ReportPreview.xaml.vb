Imports System
Imports System.Windows.Controls

Namespace DevExpress.DevAV.Views
    Partial Public Class ReportPreview
        Inherits UserControl

        Public Sub New()
            InitializeComponent()
        End Sub
    End Class
End Namespace
