﻿using System;
using DevExpress.VideoRent.ViewModel.ViewModelBase;

namespace DevExpress.VideoRent.ViewModel {
    public class RentsPeriodEditObject : EditableSubobject {
        public RentsPeriodEditObject(EditableObject parent) : base(parent) { }
        protected override void UpdateOverride() { }
    }
}
