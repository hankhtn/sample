using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IHomePhotoRepository : IRepository<HomePhoto, int> { }
}
