using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class SalesForecastView : UserControl {
        public SalesForecastView() {
            InitializeComponent();
        }
    }
}
