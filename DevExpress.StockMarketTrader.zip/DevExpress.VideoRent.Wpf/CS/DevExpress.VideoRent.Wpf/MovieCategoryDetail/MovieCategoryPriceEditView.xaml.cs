﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieCategoryPriceEditView : UserControl {
        public MovieCategoryPriceEditView() {
            InitializeComponent();
        }
    }
}
