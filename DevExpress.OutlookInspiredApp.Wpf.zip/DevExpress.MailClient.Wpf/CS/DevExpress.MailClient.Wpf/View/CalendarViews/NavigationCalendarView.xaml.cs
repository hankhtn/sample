using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class NavigationCalendarView : UserControl {
        public NavigationCalendarView() {
            InitializeComponent();
        }
    }
}
