using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class LoginButtonView : UserControl {
        public LoginButtonView() {
            InitializeComponent();
        }
    }
}
