Imports System.Reflection
Imports System.Resources
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Windows

<Assembly: AssemblyTitle("DevExpress.ProductsDemo.Wpf")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyConfiguration("")>
<Assembly: AssemblyCompany(AssemblyInfo.AssemblyCompany)>
<Assembly: AssemblyProduct("DevExpress.ProductsDemo.Wpf")>
<Assembly: AssemblyCopyright(AssemblyInfo.AssemblyCopyright)>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>

<Assembly: ComVisible(False)>
<Assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)>

<Assembly: AssemblyVersion(AssemblyInfo.Version)>
<Assembly: AssemblyFileVersion(AssemblyInfo.FileVersion)>
