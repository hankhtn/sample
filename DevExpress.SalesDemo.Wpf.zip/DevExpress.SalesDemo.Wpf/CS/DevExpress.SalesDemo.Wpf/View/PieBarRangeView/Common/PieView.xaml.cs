using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class PieView : UserControl {
        public PieView() {
            InitializeComponent();
        }
    }
}
