using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class CalendarView : UserControl {
        public CalendarView() {
            InitializeComponent();
        }
    }
}
