using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View.Common {
    public partial class NavigationView : UserControl {
        public NavigationView() {
            InitializeComponent();
        }
    }
}
