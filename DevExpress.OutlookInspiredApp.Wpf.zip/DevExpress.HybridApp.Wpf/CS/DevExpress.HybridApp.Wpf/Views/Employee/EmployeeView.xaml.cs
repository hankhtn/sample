using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class EmployeeView : UserControl {
        public EmployeeView() {
            InitializeComponent();
        }
    }
}
