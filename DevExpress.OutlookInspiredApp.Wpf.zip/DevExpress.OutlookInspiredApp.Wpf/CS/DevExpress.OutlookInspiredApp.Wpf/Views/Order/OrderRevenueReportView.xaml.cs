using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class OrderRevenueReportView : UserControl {
        public OrderRevenueReportView() {
            InitializeComponent();
        }
    }
}
