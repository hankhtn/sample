﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class CurrentCustomerRentsDetailView : DemoModule {
        public CurrentCustomerRentsDetailView() {
            InitializeComponent();
        }
    }
}
