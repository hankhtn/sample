using System;

namespace DevExpress.RealtorWorld.Xpf.DataModel {
    public interface IAgentStatisticDataRepository : IRepository<AgentStatisticData, int> { }
}
