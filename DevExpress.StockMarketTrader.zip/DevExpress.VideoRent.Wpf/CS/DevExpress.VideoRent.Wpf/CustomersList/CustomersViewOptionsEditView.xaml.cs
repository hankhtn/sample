﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class CustomersViewOptionsEditView : CustomShowUserControl {
        public CustomersViewOptionsEditView() {
            InitializeComponent();
        }
    }
}
