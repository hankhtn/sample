namespace DevExpress.DevAV.ViewModels {
    public enum CollectionViewKind {
        ListView, 
        CardView,
        Carousel,
        MasterDetailView, 
    }
}
