namespace ProductsDemo {
    public class LabelControl : VisibleControl {
        public LabelControl() {
            DefaultStyleKey = typeof(LabelControl);
        }
    }
}
