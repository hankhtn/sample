using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;




[assembly: AssemblyTitle("DevExpress.SalesDemo.Wpf")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("DevExpress.SalesDemo.Wpf")]
[assembly: AssemblyCopyright("Copyright ©  2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]




[assembly: ComVisible(false)]











[assembly: ThemeInfo(
    ResourceDictionaryLocation.None, 
    
    
    ResourceDictionaryLocation.SourceAssembly 
    
    
)]












[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
