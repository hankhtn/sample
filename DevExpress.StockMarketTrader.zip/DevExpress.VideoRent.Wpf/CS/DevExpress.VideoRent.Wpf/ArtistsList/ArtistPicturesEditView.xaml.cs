﻿using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class ArtistPicturesEditView : UserControl {
        public ArtistPicturesEditView() {
            InitializeComponent();
        }
    }
}
