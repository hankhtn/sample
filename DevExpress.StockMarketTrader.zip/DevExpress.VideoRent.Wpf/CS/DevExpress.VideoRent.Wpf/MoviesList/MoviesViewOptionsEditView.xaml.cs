﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class MoviesViewOptionsEditView : CustomShowUserControl {
        public MoviesViewOptionsEditView() {
            InitializeComponent();
        }
    }
}
