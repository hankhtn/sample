using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class OrderDocQuickReportView : UserControl {
        public OrderDocQuickReportView() {
            InitializeComponent();
        }
    }
}
