using System.Windows.Controls;

namespace DevExpress.SalesDemo.Wpf.View {
    public partial class SalesDashboard : UserControl {
        public SalesDashboard() {
            InitializeComponent();
        }
    }
}
