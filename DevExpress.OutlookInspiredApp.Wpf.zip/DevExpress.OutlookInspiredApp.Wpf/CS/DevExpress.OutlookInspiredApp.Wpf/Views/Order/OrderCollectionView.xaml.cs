using System;
using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class OrderCollectionView : UserControl {
        public OrderCollectionView() {
            InitializeComponent();
        }
    }
}
