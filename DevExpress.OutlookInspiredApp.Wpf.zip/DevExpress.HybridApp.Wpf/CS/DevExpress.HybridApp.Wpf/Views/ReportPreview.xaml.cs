using System;
using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class ReportPreview : UserControl {
        public ReportPreview() {
            InitializeComponent();
        }
    }
}
