using System.Windows.Controls;

namespace DevExpress.MailClient.View {
    public partial class MailView : UserControl {
        public MailView() {
            InitializeComponent();
        }
    }
}
