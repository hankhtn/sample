using System.Windows.Controls;

namespace DevExpress.DevAV.Views {
    public partial class EmployeeAssignView : UserControl {
        public EmployeeAssignView() {
            InitializeComponent();
        }
    }
}
