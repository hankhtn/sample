﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class CustomerDetailView : DemoModule {
        public CustomerDetailView() {
            InitializeComponent();
        }
    }
}
