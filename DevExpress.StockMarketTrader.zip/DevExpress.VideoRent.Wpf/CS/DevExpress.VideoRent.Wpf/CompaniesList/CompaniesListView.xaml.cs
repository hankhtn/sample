﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {

    public partial class CompaniesListView : DemoModule {
        public CompaniesListView() {
            InitializeComponent();
        }
    }
}
