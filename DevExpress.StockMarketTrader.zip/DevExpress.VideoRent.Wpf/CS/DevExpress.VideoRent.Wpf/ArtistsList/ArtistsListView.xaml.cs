﻿using DevExpress.VideoRent.Wpf.ModulesBase;

namespace DevExpress.VideoRent.Wpf {
    public partial class ArtistsListView : DemoModule {
        public ArtistsListView() {
            InitializeComponent();
        }
    }
}
