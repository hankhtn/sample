using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace DevExpress.RealtorWorld.Xpf.View {
    public partial class CalculatorView : UserControl {
        public CalculatorView() {
            InitializeComponent();
        }
    }
}
