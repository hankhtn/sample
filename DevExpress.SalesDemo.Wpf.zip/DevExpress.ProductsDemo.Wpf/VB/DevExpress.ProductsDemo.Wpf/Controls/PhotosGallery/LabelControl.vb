Namespace ProductsDemo
    Public Class LabelControl
        Inherits VisibleControl

        Public Sub New()
            DefaultStyleKey = GetType(LabelControl)
        End Sub
    End Class
End Namespace
