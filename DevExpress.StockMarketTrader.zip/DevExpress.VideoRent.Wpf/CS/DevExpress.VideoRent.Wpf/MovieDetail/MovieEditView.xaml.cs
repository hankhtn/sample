﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace DevExpress.VideoRent.Wpf {
    public partial class MovieEditView : UserControl {
        public MovieEditView() {
            InitializeComponent();
        }
    }
}
